// CxImageCrtDll.cpp : Defines the entry point for the CxImageCrtDll application.
//

#include "stdcrt.h"

BOOL APIENTRY DllMain( HANDLE /*hModule*/, 
                       DWORD  /*ul_reason_for_call*/, 
                       LPVOID /*lpReserved*/
					 )
{
    return TRUE;
}

