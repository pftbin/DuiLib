#include "stdafx.h"
#include "UIMicroBlog.hpp"

namespace DuiLib
{

CMicroBlogUI::CMicroBlogUI(CPaintManagerUI& paint_manager)
: paint_manager_(paint_manager)
{}

CMicroBlogUI::~CMicroBlogUI()
{}

} // namespace DuiLib